from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, abort
import sqlite3
from datetime import datetime, timedelta
from io import BytesIO
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key-before-deploying"
DB = Path(__file__).with_name("reading_champions.db")

BOOKS = [
    ("Wings of Fire", "A. P. J. Abdul Kalam"),
    ("The Jungle Book", "Rudyard Kipling"),
    ("Panchatantra", "Vishnu Sharma"),
    ("Discovery of India", "Jawaharlal Nehru"),
    ("The Story of My Experiments with Truth", "M. K. Gandhi"),
    ("Alice's Adventures in Wonderland", "Lewis Carroll"),
    ("The Adventures of Tom Sawyer", "Mark Twain"),
    ("Pride and Prejudice", "Jane Austen"),
    ("Godaan", "Munshi Premchand"),
    ("The Guide", "R. K. Narayan"),
    ("Gitanjali", "Rabindranath Tagore"),
    ("Malgudi Days", "R. K. Narayan"),
    ("The Blue Umbrella", "Ruskin Bond"),
    ("Harry Potter and the Philosopher's Stone", "J. K. Rowling"),
    ("The Little Prince", "Antoine de Saint-Exupery"),
]

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def setup_database():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS readers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            points INTEGER NOT NULL DEFAULT 0
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT UNIQUE NOT NULL,
            author TEXT NOT NULL
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS completed (
            reader_id INTEGER NOT NULL,
            book_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            PRIMARY KEY (reader_id, book_id),
            FOREIGN KEY(reader_id) REFERENCES readers(id),
            FOREIGN KEY(book_id) REFERENCES books(id)
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS bonuses (
            reader_id INTEGER NOT NULL,
            group_number INTEGER NOT NULL,
            date TEXT NOT NULL,
            PRIMARY KEY (reader_id, group_number)
        )""")
        for title, author in BOOKS:
            con.execute("INSERT OR IGNORE INTO books(title, author) VALUES (?, ?)", (title, author))

def current_reader():
    reader_id = session.get("reader_id")
    if not reader_id:
        return None
    with db() as con:
        return con.execute("SELECT id, name, points FROM readers WHERE id = ?", (reader_id,)).fetchone()

def login_required():
    reader = current_reader()
    if not reader:
        return None
    return reader

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Please enter your name to get started.", "error")
            return render_template("login.html")
        if len(name) > 60:
            flash("Please keep your name under 60 characters.", "error")
            return render_template("login.html")
        with db() as con:
            row = con.execute("SELECT id, name FROM readers WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
            if row:
                reader_id, reader_name = row["id"], row["name"]
            else:
                cur = con.execute("INSERT INTO readers(name) VALUES (?)", (name,))
                reader_id, reader_name = cur.lastrowid, name
        session["reader_id"] = reader_id
        session["reader_name"] = reader_name
        return redirect(url_for("dashboard"))
    if current_reader():
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
def dashboard():
    reader = login_required()
    if not reader:
        return redirect(url_for("index"))
    with db() as con:
        count = con.execute("SELECT COUNT(*) AS n FROM completed WHERE reader_id = ?", (reader["id"],)).fetchone()["n"]
        recent = con.execute("SELECT COUNT(*) AS n FROM completed WHERE reader_id = ? AND date >= ?",
            (reader["id"], (datetime.now() - timedelta(days=60)).isoformat())).fetchone()["n"]
        latest = con.execute("""SELECT b.title, c.date FROM completed c JOIN books b ON b.id=c.book_id
            WHERE c.reader_id=? ORDER BY c.date DESC LIMIT 4""", (reader["id"],)).fetchall()
        rank = con.execute("SELECT COUNT(*) + 1 AS rank FROM readers WHERE points > ?", (reader["points"],)).fetchone()["rank"]
    return render_template("dashboard.html", reader=reader, count=count, recent=recent, latest=latest, rank=rank,
                           progress=min(100, reader["points"] / 2000 * 100))

@app.route("/books")
def books():
    reader = login_required()
    if not reader:
        return redirect(url_for("index"))
    query = request.args.get("q", "").strip()
    with db() as con:
        rows = con.execute("""SELECT b.id, b.title, b.author,
            CASE WHEN c.book_id IS NULL THEN 0 ELSE 1 END AS done, c.date
            FROM books b LEFT JOIN completed c ON c.book_id=b.id AND c.reader_id=?
            WHERE b.title LIKE ? OR b.author LIKE ? ORDER BY b.title""",
            (reader["id"], f"%{query}%", f"%{query}%")).fetchall()
    return render_template("books.html", reader=reader, books=rows, query=query)

@app.route("/books/<int:book_id>/complete", methods=["POST"])
def complete_book(book_id):
    reader = login_required()
    if not reader:
        return redirect(url_for("index"))
    now = datetime.now()
    with db() as con:
        book = con.execute("SELECT id, title FROM books WHERE id=?", (book_id,)).fetchone()
        if not book:
            abort(404)
        already = con.execute("SELECT 1 FROM completed WHERE reader_id=? AND book_id=?", (reader["id"], book_id)).fetchone()
        if already:
            flash("You've already marked this book as completed.", "info")
            return redirect(url_for("books"))
        con.execute("INSERT INTO completed(reader_id, book_id, date) VALUES (?, ?, ?)",
                    (reader["id"], book_id, now.isoformat()))
        con.execute("UPDATE readers SET points=points+10 WHERE id=?", (reader["id"],))
        cutoff = (now - timedelta(days=60)).isoformat()
        recent_count = con.execute("SELECT COUNT(*) AS n FROM completed WHERE reader_id=? AND date>=?",
                                   (reader["id"], cutoff)).fetchone()["n"]
        earned_groups = recent_count // 3
        previous_groups = con.execute("SELECT COUNT(*) AS n FROM bonuses WHERE reader_id=?", (reader["id"],)).fetchone()["n"]
        if earned_groups > previous_groups:
            for group in range(previous_groups + 1, earned_groups + 1):
                con.execute("INSERT OR IGNORE INTO bonuses(reader_id, group_number, date) VALUES (?, ?, ?)",
                            (reader["id"], group, now.isoformat()))
            con.execute("UPDATE readers SET points=points+? WHERE id=?",
                        ((earned_groups - previous_groups) * 100, reader["id"]))
    flash(f'Nice work! “{book["title"]}” completed — 10 points added.', "success")
    return redirect(url_for("books"))

@app.route("/certificates")
def certificates():
    reader = login_required()
    if not reader:
        return redirect(url_for("index"))
    with db() as con:
        completed = con.execute("""SELECT b.id, b.title, b.author, c.date
            FROM completed c JOIN books b ON b.id=c.book_id
            WHERE c.reader_id=? ORDER BY c.date DESC""", (reader["id"],)).fetchall()
    return render_template("certificates.html", reader=reader, completed=completed)

@app.route("/certificates/<int:book_id>/download")
def download_certificate(book_id):
    reader = login_required()
    if not reader:
        return redirect(url_for("index"))
    with db() as con:
        row = con.execute("""SELECT b.title, b.author, c.date FROM completed c
            JOIN books b ON b.id=c.book_id WHERE c.reader_id=? AND b.id=?""",
            (reader["id"], book_id)).fetchone()
    if not row:
        abort(404)
    date = row["date"][:10]
    certificate = f"""==========================================
       CERTIFICATE OF ACHIEVEMENT
          INDIA READING CHAMPIONS
==========================================

This certificate is awarded to:

   {reader['name']}

For completing the book:

   {row['title']}
Author: {row['author']}
Completion date: {date}

Keep reading and keep learning!
==========================================
"""
    return send_file(BytesIO(certificate.encode("utf-8")), as_attachment=True,
                     download_name="Reading_Certificate.txt", mimetype="text/plain; charset=utf-8")

@app.route("/rewards")
def rewards():
    reader = login_required()
    if not reader:
        return redirect(url_for("index"))
    with db() as con:
        count = con.execute("SELECT COUNT(*) AS n FROM completed WHERE reader_id=?", (reader["id"],)).fetchone()["n"]
    return render_template("rewards.html", reader=reader, count=count, remaining=max(0, 2000-reader["points"]))

@app.route("/leaderboard")
def leaderboard():
    reader = login_required()
    if not reader:
        return redirect(url_for("index"))
    with db() as con:
        rows = con.execute("SELECT id, name, points FROM readers ORDER BY points DESC, name ASC LIMIT 50").fetchall()
    return render_template("leaderboard.html", reader=reader, readers=rows)

@app.errorhandler(404)
def not_found(_):
    return render_template("404.html"), 404

if __name__ == "__main__":
    setup_database()
    app.run(debug=True)
