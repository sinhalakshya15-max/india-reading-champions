# India Reading Champions — Website

A Flask website version of the original Tkinter reading tracker.

## Features
- Reader profile by name (same name returns to the same profile)
- SQLite database for readers, books, completions, and bonuses
- Searchable 15-book starter library
- Book completion tracking (+10 points)
- Bonus rules based on the original program
- Downloadable text certificates
- Points and rewards page
- Leaderboard
- Responsive layout for desktop and mobile

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install Flask:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Start the website:

   ```bash
   python app.py
   ```

5. Open http://127.0.0.1:5000 in your browser.

The SQLite database `reading_champions.db` is created automatically on first run.

## Important before deploying publicly
- Change `app.secret_key` in `app.py` to a long, random secret.
- This starter app uses name-only profiles, not secure authentication. Anyone who knows a reader name could open that profile. Add proper authentication before using it with real users.
- The leaderboard displays reader names and points to other users of the same database.
- Use a production WSGI server (such as Waitress or Gunicorn) and turn off debug mode.
- This is a local starter project, not yet hosted online.

## Bonus calculation note
The bonus logic intentionally follows the supplied Python program's calculation. For a public competition, consider revising the logic to make bonus groups unambiguous when the rolling 60-day count changes.
